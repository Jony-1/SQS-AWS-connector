package org.example.kafkaSQS;

import org.apache.kafka.common.config.AbstractConfig;
import org.apache.kafka.common.config.ConfigDef;

import java.util.Map;

public class SqsConnectorConfig extends AbstractConfig {

    public static final String SQS_QUEUE_URL = "sqs.queue.url";
    public static final String SQS_QUEUE_NAME = "sqs.queue.name";
    public static final String AWS_ACCESS_KEY = "aws.access.key";
    public static final String AWS_SECRET_KEY = "aws.secret.key";
    public static final String AWS_REGION = "aws.region";
    public static final String KAFKA_TOPICS = "topics";
    public static final String PROXY_HOST = "proxy.host";
    public static final String PROXY_PORT = "proxy.port";

    // Source
    public static final String OUTPUT_FORMAT  = "output.format";   // string | bytes
    public static final String JSON_AS_STRUCT = "json.as.struct";  // true | false

    // SWIFT / XML
    public static final String SWIFT_MT_CCSID   = "swift.mt.ccsid";    // "819" (ISO-8859-1)
    public static final String SWIFT_MT_TARGET  = "swift.mt.target";   // none | keep | 103 | 199
    public static final String SWIFT_MT_REWRITE = "swift.mt.rewrite";  // block2-only
    public static final String XML_TARGET_CCSID = "xml.target.ccsid";  // "819" por defecto

    public SqsConnectorConfig(Map<String, String> originals) {
        super(config(), originals);
    }

    public static ConfigDef config() {
        return new ConfigDef()
            .define(SQS_QUEUE_URL, ConfigDef.Type.STRING, null, ConfigDef.Importance.MEDIUM,
                    "Complete SQS Queue URL (optional)")
            .define(SQS_QUEUE_NAME, ConfigDef.Type.STRING, null, ConfigDef.Importance.MEDIUM,
                    "Name of the SQS Queue (used if URL is not provided)")
            .define(AWS_ACCESS_KEY, ConfigDef.Type.STRING, null, ConfigDef.Importance.MEDIUM,
                    "AWS Access Key (optional)")
            .define(AWS_SECRET_KEY, ConfigDef.Type.STRING, null, ConfigDef.Importance.MEDIUM,
                    "AWS Secret Key (optional)")
            .define(AWS_REGION, ConfigDef.Type.STRING, "us-east-1", ConfigDef.Importance.MEDIUM,
                    "AWS Region (optional)")
            .define(KAFKA_TOPICS, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH,
                    "Comma-separated list of Kafka topics to write to")
            .define(PROXY_HOST, ConfigDef.Type.STRING, null, ConfigDef.Importance.LOW,
                    "Proxy host for AWS connections")
            .define(PROXY_PORT, ConfigDef.Type.INT, null, ConfigDef.Importance.LOW,
                    "Proxy port for AWS connections")

            // Formato de salida
            .define(OUTPUT_FORMAT, ConfigDef.Type.STRING, "bytes", ConfigDef.Importance.MEDIUM,
                    "Kafka value format: string | bytes (use bytes to guarantee target encodings)")
            .define(JSON_AS_STRUCT, ConfigDef.Type.BOOLEAN, false, ConfigDef.Importance.MEDIUM,
                    "If true, publish JSON as Map/List (requires JsonConverter)")

            // SWIFT / XML
            .define(SWIFT_MT_CCSID, ConfigDef.Type.STRING, "819", ConfigDef.Importance.MEDIUM,
                    "Target CCSID for SWIFT MT (819=ISO-8859-1, 1208=UTF-8, etc.)")
            .define(SWIFT_MT_TARGET, ConfigDef.Type.STRING, "103", ConfigDef.Importance.MEDIUM,
                    "Target MT type rewrite for block 2: none|keep|103|199")
            .define(SWIFT_MT_REWRITE, ConfigDef.Type.STRING, "block2-only", ConfigDef.Importance.LOW,
                    "Rewrite mode. 'block2-only' changes only {2:Ixxx...}/{2:Oxxx...}")
            .define(XML_TARGET_CCSID, ConfigDef.Type.STRING, "819", ConfigDef.Importance.MEDIUM,
                    "Target CCSID for XML (e.g., 819=ISO-8859-1)");
    }
}
