package org.example.kafkaSQS;

import org.apache.kafka.connect.source.SourceRecord;
import org.apache.kafka.connect.source.SourceTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.http.SdkHttpClient;
import software.amazon.awssdk.http.urlconnection.ProxyConfiguration;
import software.amazon.awssdk.http.urlconnection.UrlConnectionHttpClient;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.SqsClientBuilder;
import software.amazon.awssdk.services.sqs.model.Message;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageRequest;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.net.URI;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SqsSourceTask extends SourceTask {

    private static final Logger log = LoggerFactory.getLogger(SqsSourceTask.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    // {2:Ixxx...} / {2:Oxxx...} con 3 dígitos exactos
    private static final Pattern P_BLOCK2_TYPE = Pattern.compile("\\{2:\\s*([IO])(\\d{3})([^}]*)\\}");

    private SqsClient sqsClient;
    private String queueUrl;
    private String kafkaTopics;

    // Config
    private String outputFormat;        // string | bytes
    private boolean jsonAsStruct;       // true => publica JSON como Map/List
    private String swiftMtCcsid;        // "819"
    private Charset swiftMtCharset;     // Charset CCSID SWIFT
    private String swiftMtTarget;       // none | keep | 103 | 199
    private String swiftMtRewrite;      // block2-only
    private String xmlTargetCcsid;      // "819"
    private Charset xmlTargetCharset;   // Charset CCSID XML

    @Override public String version() { return "1.5"; }

    @Override
    public void start(Map<String, String> props) {
        String accessKey    = props.get(SqsConnectorConfig.AWS_ACCESS_KEY);
        String secretKey    = props.get(SqsConnectorConfig.AWS_SECRET_KEY);
        String region       = props.getOrDefault(SqsConnectorConfig.AWS_REGION, "us-east-1");
        String queueName    = props.get(SqsConnectorConfig.SQS_QUEUE_NAME);
        String queueUrlProp = props.get(SqsConnectorConfig.SQS_QUEUE_URL);
        kafkaTopics         = props.get(SqsConnectorConfig.KAFKA_TOPICS);

        outputFormat    = Optional.ofNullable(props.get(SqsConnectorConfig.OUTPUT_FORMAT)).orElse("bytes").toLowerCase(Locale.ROOT);
        jsonAsStruct    = Boolean.parseBoolean(Optional.ofNullable(props.get(SqsConnectorConfig.JSON_AS_STRUCT)).orElse("false"));
        swiftMtCcsid    = Optional.ofNullable(props.get(SqsConnectorConfig.SWIFT_MT_CCSID)).orElse("819").trim();
        swiftMtCharset  = mapCcsidToCharset(swiftMtCcsid);
        swiftMtTarget   = Optional.ofNullable(props.get(SqsConnectorConfig.SWIFT_MT_TARGET)).orElse("103").toLowerCase(Locale.ROOT);
        swiftMtRewrite  = Optional.ofNullable(props.get(SqsConnectorConfig.SWIFT_MT_REWRITE)).orElse("block2-only").toLowerCase(Locale.ROOT);
        xmlTargetCcsid  = Optional.ofNullable(props.get(SqsConnectorConfig.XML_TARGET_CCSID)).orElse("819").trim();
        xmlTargetCharset= mapCcsidToCharset(xmlTargetCcsid);

        // Proxy (opcional)
        String proxyHost = props.get(SqsConnectorConfig.PROXY_HOST);
        Integer proxyPort = props.containsKey(SqsConnectorConfig.PROXY_PORT)
                ? Integer.parseInt(props.get(SqsConnectorConfig.PROXY_PORT))
                : null;

        UrlConnectionHttpClient.Builder httpBuilder = UrlConnectionHttpClient.builder();
        if (proxyHost != null && proxyPort != null) {
            ProxyConfiguration proxyCfg = ProxyConfiguration.builder()
                    .endpoint(URI.create("http://" + proxyHost + ":" + proxyPort))
                    .build();
            httpBuilder.proxyConfiguration(proxyCfg);
            log.info("Usando proxy HTTP {}:{}", proxyHost, proxyPort);
        }
        SdkHttpClient httpClient = httpBuilder.build();

        // Cliente SQS
        SqsClientBuilder builder = SqsClient.builder()
                .region(Region.of(region))
                .httpClient(httpClient);

        if (accessKey != null && secretKey != null) {
            builder.credentialsProvider(StaticCredentialsProvider.create(AwsBasicCredentials.create(accessKey, secretKey)));
            log.info("Inicializando SQS client con credenciales estáticas en región {}", region);
        } else {
            builder.credentialsProvider(DefaultCredentialsProvider.create());
            log.info("Inicializando SQS client con DefaultCredentialsProvider en región {}", region);
        }
        sqsClient = builder.build();

        // Resolver URL de la cola
        queueUrl = (queueUrlProp != null && !queueUrlProp.isEmpty())
                ? queueUrlProp
                : sqsClient.getQueueUrl(b -> b.queueName(queueName)).queueUrl();

        log.info("SQS Source listo. QueueUrl={}, topic={}, swift.mt.ccsid={} ({}), xml.ccsid={} ({}) target={}",
                this.queueUrl, this.kafkaTopics,
                this.swiftMtCcsid, swiftMtCharset.displayName(),
                this.xmlTargetCcsid, xmlTargetCharset.displayName(),
                swiftMtTarget);
    }

    @Override
    public List<SourceRecord> poll() throws InterruptedException {
        List<SourceRecord> out = new ArrayList<>();

        ReceiveMessageRequest req = ReceiveMessageRequest.builder()
                .queueUrl(queueUrl)
                .maxNumberOfMessages(10)
                .waitTimeSeconds(20)
                .messageAttributeNames("All")
                .build();

        List<Message> messages = sqsClient.receiveMessage(req).messages();
        if (!messages.isEmpty()) {
            log.info("Recibidos {} mensajes de SQS", messages.size());
        }

        for (Message msg : messages) {
            String body = msg.body();
            if (body == null) body = "";

            // 1) SWIFT MT
            if (looksLikeSwiftMT(body)) {
                String normalized = normalizeSwiftMT(body);
                String mtType = detectSwiftMTType(normalized);

                if (!"none".equals(swiftMtTarget) && !"keep".equals(swiftMtTarget)) {
                    if (mtType == null || !mtType.equals(swiftMtTarget)) {
                        normalized = rewriteSwiftMTType(normalized, swiftMtTarget, swiftMtRewrite);
                        mtType = detectSwiftMTType(normalized);
                    }
                }

                SourceRecord rec;
                if ("bytes".equals(outputFormat)) {
                    byte[] mtBytes = normalized.getBytes(swiftMtCharset); // => 819 garantizado en wire
                    rec = new SourceRecord(null, null, kafkaTopics, null, null, null, mtBytes);
                } else {
                    rec = new SourceRecord(null, null, kafkaTopics, null, null, null, normalized); // String (UTF-8 por converter)
                }

                rec.headers().addString("sqs-message-id", safe(msg.messageId()));
                rec.headers().addString("detected-format", "swift-mt");
                if (mtType != null) rec.headers().addString("swift-mt-type", mtType);
                rec.headers().addString("swift-mt-target", swiftMtTarget);
                rec.headers().addString("swift-mt-rewrite", swiftMtRewrite);
                rec.headers().addString("swift-mt-ccsid", swiftMtCcsid);
                rec.headers().addString("swift-mt-charset", swiftMtCharset.displayName());
                rec.headers().addString("content-type", "text/mt");

                out.add(rec);
                sqsClient.deleteMessage(b -> b.queueUrl(queueUrl).receiptHandle(msg.receiptHandle()));
                log.info("MT publicado | id={} | type={} | target={} | ccsid={} ({})",
                        safe(msg.messageId()), safe(mtType), swiftMtTarget, swiftMtCcsid, swiftMtCharset.displayName());
                continue;
            }

            // 2) XML
            String trimmed = body.stripLeading();
            if (trimmed.startsWith("<")) {
                String xml = ensureXmlIso88591(body); // prolog encoding="ISO-8859-1"
                SourceRecord rec;
                if ("bytes".equals(outputFormat)) {
                    byte[] xmlBytes = xml.getBytes(xmlTargetCharset); // => 819 en wire si así lo configuras
                    rec = new SourceRecord(null, null, kafkaTopics, null, null, null, xmlBytes);
                } else {
                    rec = new SourceRecord(null, null, kafkaTopics, null, null, null, xml);
                }

                rec.headers().addString("sqs-message-id", safe(msg.messageId()));
                rec.headers().addString("detected-format", "xml");
                rec.headers().addString("xml-ccsid", xmlTargetCcsid);
                rec.headers().addString("xml-charset", xmlTargetCharset.displayName());
                rec.headers().addString("content-type", "text/xml");

                out.add(rec);
                sqsClient.deleteMessage(b -> b.queueUrl(queueUrl).receiptHandle(msg.receiptHandle()));
                log.info("XML publicado | id={} | ccsid={} ({})",
                        safe(msg.messageId()), xmlTargetCcsid, xmlTargetCharset.displayName());
                continue;
            }

            // 3) JSON con campo que contiene MT (por si acaso)
            if (looksLikeJson(body)) {
                String mtFromJson = tryExtractSwiftFromJson(body);
                if (mtFromJson != null) {
                    String normalized = normalizeSwiftMT(mtFromJson);
                    String mtType = detectSwiftMTType(normalized);
                    if (!"none".equals(swiftMtTarget) && !"keep".equals(swiftMtTarget)) {
                        if (mtType == null || !mtType.equals(swiftMtTarget)) {
                            normalized = rewriteSwiftMTType(normalized, swiftMtTarget, swiftMtRewrite);
                            mtType = detectSwiftMTType(normalized);
                        }
                    }
                    SourceRecord rec;
                    if ("bytes".equals(outputFormat)) {
                        byte[] mtBytes = normalized.getBytes(swiftMtCharset);
                        rec = new SourceRecord(null, null, kafkaTopics, null, null, null, mtBytes);
                    } else {
                        rec = new SourceRecord(null, null, kafkaTopics, null, null, null, normalized);
                    }
                    rec.headers().addString("sqs-message-id", safe(msg.messageId()));
                    rec.headers().addString("detected-format", "swift-mt");
                    if (mtType != null) rec.headers().addString("swift-mt-type", mtType);
                    rec.headers().addString("swift-mt-target", swiftMtTarget);
                    rec.headers().addString("swift-mt-rewrite", swiftMtRewrite);
                    rec.headers().addString("swift-mt-ccsid", swiftMtCcsid);
                    rec.headers().addString("swift-mt-charset", swiftMtCharset.displayName());
                    rec.headers().addString("content-type", "text/mt");

                    out.add(rec);
                    sqsClient.deleteMessage(b -> b.queueUrl(queueUrl).receiptHandle(msg.receiptHandle()));
                    log.info("MT (desde JSON) publicado | id={} | type={} | target={} | ccsid={} ({})",
                            safe(msg.messageId()), safe(mtType), swiftMtTarget, swiftMtCcsid, swiftMtCharset.displayName());
                    continue;
                }
            }

            // 4) Resto (texto/otros) – se publica tal cual
            SourceRecord rec;
            if ("bytes".equals(outputFormat)) {
                // Por compatibilidad, publicamos en UTF-8
                byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
                rec = new SourceRecord(null, null, kafkaTopics, null, null, null, bytes);
            } else {
                rec = new SourceRecord(null, null, kafkaTopics, null, null, null, body);
            }
            rec.headers().addString("sqs-message-id", safe(msg.messageId()));
            rec.headers().addString("detected-format", "text");
            rec.headers().addString("content-type", "text/plain");

            out.add(rec);
            sqsClient.deleteMessage(b -> b.queueUrl(queueUrl).receiptHandle(msg.receiptHandle()));
            log.info("Texto publicado | id={}", safe(msg.messageId()));
        }

        return out;
    }

    @Override
    public void stop() {
        if (sqsClient != null) {
            try { sqsClient.close(); } catch (Exception e) { log.warn("Error cerrando SQS client", e); }
        }
        log.info("SQS Source detenido.");
    }

    // ===== Helpers =====

    private boolean looksLikeSwiftMT(String s) {
        if (s == null) return false;
        String t = s.trim();
        return t.startsWith("{1:") && t.contains("}{2:") && t.contains("}{4:");
    }

    private String normalizeSwiftMT(String s) {
        if (s == null) return null;


        String out = s;

        if (out.contains("\\r\\n")) {
            out = out.replace("\\r\\n", "\r\n");
        }
        if (out.contains("\\n") && !out.contains("\r\n")) {
            out = out.replace("\\n", "\n");
        }
        if (out.contains("\\r") && !out.contains("\r\n")) {
            out = out.replace("\\r", "\r");
        }


        out = out.replaceAll("(?<!\\r)\\n", "\r\n");
        out = out.replaceAll("\\r(?!\\n)", "\r\n");

        return out;
    }

    private String detectSwiftMTType(String mt) {
        if (mt == null) return null;
        Matcher m = P_BLOCK2_TYPE.matcher(mt);
        if (m.find()) return m.group(2);
        return null;
    }

    private String rewriteSwiftMTType(String mt, String targetType, String rewriteMode) {
        if (!"block2-only".equals(rewriteMode) || mt == null || targetType == null) return mt;
        Matcher m = P_BLOCK2_TYPE.matcher(mt);
        if (!m.find()) return mt;
        String io   = m.group(1);
        String cur  = m.group(2);
        String rest = m.group(3);
        if (targetType.equals(cur)) return mt;

        String replacement = "{2:" + io + targetType + rest + "}";
        StringBuffer sb = new StringBuffer();
        m.appendReplacement(sb, Matcher.quoteReplacement(replacement));
        m.appendTail(sb);
        return sb.toString();
    }

    private String ensureXmlIso88591(String xml) {
        if (xml == null) return null;
        String s = xml;
        int i = s.indexOf("<?xml");
        if (i == 0) {
            int end = s.indexOf("?>", 5);
            if (end > 0) {
                String prolog = s.substring(0, end + 2);
                String rest   = s.substring(end + 2);
                String newProlog;
                if (prolog.toLowerCase(Locale.ROOT).contains("encoding=")) {
                    newProlog = prolog.replaceAll("(?i)encoding\\s*=\\s*\"[^\"]*\"", "encoding=\"ISO-8859-1\"");
                } else {
                    newProlog = prolog.replace("?>", " encoding=\"ISO-8859-1\"?>");
                }
                return newProlog + rest;
            } else {
                // prolog abierto, mejor inyectar uno nuevo arriba
                return "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>" + s;
            }
        } else {
            // sin prolog
            return "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>" + s;
        }
    }

    private static boolean looksLikeJson(String s) {
        if (s == null) return false;
        String t = s.trim();
        if (t.isEmpty()) return false;
        char c = t.charAt(0);
        if (c != '{' && c != '[') return false;
        try { MAPPER.readTree(t); return true; } catch (Exception e) { return false; }
    }

    private String tryExtractSwiftFromJson(String json) {
        try {
            JsonNode root = MAPPER.readTree(json);
            if (root != null && root.isObject()) {
                String[] keys = new String[]{"mt", "swift", "swift_mt", "mq_mt", "mtMessage"};
                for (String k : keys) {
                    JsonNode n = root.get(k);
                    if (n != null && n.isTextual()) {
                        String candidate = n.asText();
                        if (looksLikeSwiftMT(candidate)) return candidate;
                    }
                }
            }
        } catch (Exception ignore) { }
        return null;
    }

    private static String safe(String s) { return (s == null) ? "" : s; }

    /** Mapea CCSID IBM comunes a Charset de Java. */
    private static Charset mapCcsidToCharset(String ccsidOrName) {
        if (ccsidOrName == null) return StandardCharsets.ISO_8859_1;
        String v = ccsidOrName.trim().toLowerCase(Locale.ROOT);

        if (v.equals("iso-8859-1") || v.equals("latin1") || v.equals("latin-1")) return StandardCharsets.ISO_8859_1;
        if (v.equals("utf-8") || v.equals("1208")) return StandardCharsets.UTF_8;

        switch (v) {
            case "819":  return StandardCharsets.ISO_8859_1; // Latin-1
            case "1208": return StandardCharsets.UTF_8;      // UTF-8
            case "273":  return Charset.forName("Cp273");     // EBCDIC Germany
            case "037":
            case "37":   return Charset.forName("Cp037");     // EBCDIC US
            case "285":  return Charset.forName("Cp285");     // EBCDIC UK
            default:
                try { return Charset.forName(ccsidOrName); }
                catch (Exception ignore) { return StandardCharsets.ISO_8859_1; }
        }
    }
}
