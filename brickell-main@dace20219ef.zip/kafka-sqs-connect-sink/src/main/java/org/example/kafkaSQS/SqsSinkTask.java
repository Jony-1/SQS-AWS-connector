package org.example.kafkaSQS;

import org.apache.kafka.connect.sink.SinkRecord;
import org.apache.kafka.connect.sink.SinkTask;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.http.SdkHttpClient;
import software.amazon.awssdk.http.urlconnection.ProxyConfiguration;
import software.amazon.awssdk.http.urlconnection.UrlConnectionHttpClient;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.SqsClientBuilder;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;

import java.net.URI;
import java.util.Collection;
import java.util.Map;
import java.util.HashMap;
import java.util.UUID;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.fasterxml.jackson.databind.ObjectMapper;

public class SqsSinkTask extends SinkTask {

    private SqsClient sqsClient;
    private String queueUrl;
    private String topics;
    
    private Set<String> upsilonTopics;
    private UpsilonClient upsilonClient;
    private boolean upsilonEnabled;
    private ObjectMapper objectMapper;

    // Executor para envíos diferidos a SQS
    private ScheduledExecutorService scheduledExecutor;

    // Tiempo de retraso configurable para envío a SQS (en minutos)
    private int sqsDelayMinutes;

    @Override
    public String version() {
        return "1.0";
    }

    @Override
    public void start(Map<String, String> props) {
        String accessKey = props.get(SqsConnectorConfig.AWS_ACCESS_KEY);
        String secretKey = props.get(SqsConnectorConfig.AWS_SECRET_KEY);
        String region = props.get(SqsConnectorConfig.AWS_REGION);
        String queueUrlFromConfig = props.get(SqsConnectorConfig.SQS_QUEUE_URL);
        String queueName = props.get(SqsConnectorConfig.SQS_QUEUE_NAME);
        String proxyHost = props.get(SqsConnectorConfig.PROXY_HOST);
        Integer proxyPort = props.containsKey(SqsConnectorConfig.PROXY_PORT)
                ? Integer.parseInt(props.get(SqsConnectorConfig.PROXY_PORT))
                : null;
        topics = props.get(SqsConnectorConfig.KAFKA_TOPICS);

        // Configurar el proxy para SdkHttpClient
        ProxyConfiguration.Builder proxyConfig = ProxyConfiguration.builder();
        if (proxyHost != null && proxyPort != null) {
            proxyConfig.endpoint(URI.create("http://" + proxyHost + ":" + proxyPort));
        }

        SdkHttpClient httpClient = UrlConnectionHttpClient.builder()
                .proxyConfiguration(proxyConfig.build())
                .build();

        SqsClientBuilder sqsClientBuilder = SqsClient.builder()
                .region(Region.of(region))
                .httpClient(httpClient);

        // Configuración de credenciales
        if (accessKey != null && secretKey != null) {
            sqsClientBuilder.credentialsProvider(
                    StaticCredentialsProvider.create(AwsBasicCredentials.create(accessKey, secretKey))
            );
        } else {
            sqsClientBuilder.credentialsProvider(DefaultCredentialsProvider.create());
        }

        sqsClient = sqsClientBuilder.build();


        // Configurar la URL de la cola SQS
        if (queueUrlFromConfig != null && !queueUrlFromConfig.isEmpty()) {
            this.queueUrl = queueUrlFromConfig;
        } else if (queueName != null && !queueName.isEmpty()) {
            this.queueUrl = sqsClient.getQueueUrl(builder -> builder.queueName(queueName)).queueUrl();
        } else {
            throw new IllegalArgumentException("Debe proporcionar una URL de cola SQS o un nombre de cola.");
        }

        // Configurar procesamiento XML y envío a Upsilon
        String upsilonTopicsStr = props.get(SqsConnectorConfig.UPSILON_TOPICS);
        upsilonEnabled = Boolean.parseBoolean(props.getOrDefault(SqsConnectorConfig.UPSILON_ENABLED, "true"));

        if (upsilonTopicsStr != null && !upsilonTopicsStr.isEmpty()) {
            // Dividir y limpiar espacios en blanco antes de crear el Set
            String[] topicsArray = upsilonTopicsStr.split(",");
            upsilonTopics = new HashSet<>();
            for (String topic : topicsArray) {
                upsilonTopics.add(topic.trim());
            }
        } else {
            upsilonTopics = new HashSet<>();
        }

        // Inicializar ObjectMapper para JSON
        objectMapper = new ObjectMapper();

        // Configurar cliente Upsilon si está habilitado y hay configuración completa
        if (upsilonEnabled && !upsilonTopics.isEmpty()) {
            String upsilonBaseUrl = props.get(SqsConnectorConfig.UPSILON_BASE_URL);
            String upsilonNamespace = props.get(SqsConnectorConfig.UPSILON_NAMESPACE);
            String upsilonStreamId = props.get(SqsConnectorConfig.UPSILON_STREAM_ID);
            String upsilonRecordType = props.get(SqsConnectorConfig.UPSILON_RECORD_TYPE_ID);
            String authToken = props.get(SqsConnectorConfig.UPSILON_AUTH_TOKEN);

            // Soporte para configuración nueva (Upsilon) y legacy (endpoint directo)
            if (upsilonBaseUrl != null && upsilonNamespace != null && upsilonStreamId != null && authToken != null) {
                // Configuración nueva con Upsilon separado
                upsilonClient = new UpsilonClient(upsilonBaseUrl, upsilonNamespace, upsilonStreamId, upsilonRecordType, authToken);
                System.out.println("✅ Cliente Upsilon configurado:");
                System.out.println("   - Base URL: " + upsilonBaseUrl);
                System.out.println("   - Namespace: " + upsilonNamespace);
                System.out.println("   - Stream ID: " + upsilonStreamId);
                System.out.println("   - Record Type: " + upsilonRecordType);
                System.out.println("   - Tópicos Kafka configurados: " + upsilonTopics);
            } else {
                // Configuración legacy para compatibilidad hacia atrás
                String legacyEndpoint = props.get(SqsConnectorConfig.UPSILON_ENDPOINT);
                if (legacyEndpoint != null && authToken != null) {
                    upsilonClient = new UpsilonClient(legacyEndpoint, authToken);
                    System.out.println("⚠️ Cliente Upsilon configurado en modo legacy:");
                    System.out.println("   - Endpoint: " + legacyEndpoint);
                    System.out.println("   - Tópicos Kafka configurados: " + upsilonTopics);
                } else {
                    System.out.println("❌ Warning: Upsilon habilitado pero configuración incompleta. Se enviará solo a SQS.");
                    upsilonEnabled = false;
                }
            }
        }

        // Configurar tiempo de retraso para SQS (valor por defecto: 5 minutos)
        sqsDelayMinutes = Integer.parseInt(props.getOrDefault(SqsConnectorConfig.SQS_DELAY_MINUTES, "5"));

        // Inicializar executor para envíos diferidos
        scheduledExecutor = Executors.newScheduledThreadPool(2);

        System.out.println("⏰ Configuración de retraso SQS: " + sqsDelayMinutes + " minutos");
    }

    @Override
    public void put(Collection<SinkRecord> records) {
        for (SinkRecord record : records) {
            String messageBody = record.value() != null ? record.value().toString() : "";
            String topicName = record.topic();

            if (!messageBody.isEmpty()) {
                // Caso 1: tópico pertenece a los de Upsilon → enviar a Upsilon inmediatamente Y SQS después de 5 minutos
                if (upsilonEnabled && upsilonClient != null && upsilonTopics.contains(topicName)) {

                    // 1. Enviar inmediatamente a Upsilon (procesado)
                    boolean sentToUpsilon = processAndSendToUpsilon(record, messageBody, topicName);

                    if (sentToUpsilon) {
                        System.out.println("✅ Mensaje del tópico '" + topicName + "' enviado a Upsilon Streams");

                        // 2. Programar envío a SQS después de 5 minutos (mensaje original sin procesar)
                        scheduleDelayedSqsSend(record, messageBody, topicName);

                    } else {
                        System.err.println("❌ Error procesando mensaje para Upsilon desde tópico '" + topicName + "'");

                        // Si falla Upsilon, enviar inmediatamente a SQS como fallback
                        sendToSqs(record, messageBody);
                        System.out.println("📩 Mensaje del tópico '" + topicName + "' enviado a SQS (fallback por error Upsilon)");
                    }

                    // Caso 2: otros tópicos → enviar SOLO a SQS inmediatamente
                } else {
                    sendToSqs(record, messageBody);
                    System.out.println("📩 Mensaje del tópico '" + topicName + "' enviado a SQS");
                }

            } else {
                System.out.println("⚠️ Mensaje vacío del tópico '" + topicName + "', omitiendo envío.");
            }
        }
    }

    /**
     * Programa el envío diferido del mensaje original a SQS después del tiempo configurado
     */
    private void scheduleDelayedSqsSend(SinkRecord record, String originalMessageBody, String topicName) {
        scheduledExecutor.schedule(() -> {
            try {
                // Enviar el mensaje original (sin procesar) a SQS
                sendToSqs(record, originalMessageBody);
                System.out.println("📩⏰ Mensaje del tópico '" + topicName + "' enviado a SQS (diferido " + sqsDelayMinutes + " min)");
            } catch (Exception e) {
                System.err.println("❌ Error en envío diferido a SQS para tópico '" + topicName + "': " + e.getMessage());
                e.printStackTrace();
            }
        }, sqsDelayMinutes, TimeUnit.MINUTES);

        System.out.println("⏰ Programado envío a SQS en " + sqsDelayMinutes + " minutos para tópico '" + topicName + "'");
    }

    private boolean processAndSendToUpsilon(SinkRecord record, String messageBody, String topicName) {
        try {
            Map<String, Object> extractedData;

            if (XmlProcessor.isXmlMessage(messageBody)) {
                System.out.println("Procesando mensaje XML del tópico: " + topicName);
                extractedData = XmlProcessor.extractDataFromXml(messageBody);
            } else {
                System.out.println("Procesando mensaje JSON del tópico: " + topicName);
                extractedData = objectMapper.readValue(messageBody, Map.class);
            }

            // Agregar metadatos de Kafka para Upsilon
            extractedData.put("kafkaMetadata", createKafkaMetadata(record));
            extractedData.put("processedAt", System.currentTimeMillis());
            extractedData.put("sourceTopic", topicName);

            // Agregar información específica para Upsilon
            extractedData.put("messageFormat", XmlProcessor.isXmlMessage(messageBody) ? "xml" : "json");
            extractedData.put("connectorOrigin", "kafka-upsilon-connector");
            extractedData.put("streamTimestamp", System.currentTimeMillis());

            // Enviar a Upsilon Stream usando putRecord
            boolean success = upsilonClient.putRecord(extractedData);

            if (success) {
                System.out.println("📊 Mensaje enviado exitosamente a Upsilon Stream desde tópico: " + topicName);
            } else {
                System.err.println("❌ Error enviando mensaje a Upsilon Stream desde tópico: " + topicName);
            }

            return success;

        } catch (Exception e) {
            System.err.println("⚠️ Error procesando mensaje para Upsilon del tópico '" + topicName + "': " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }


    private void sendToSqs(SinkRecord record, String messageBody) {
        try {

            String messageGroupId = "default-group";

            String messageDeduplicationId = record.key() != null ? record.key().toString() : UUID.randomUUID().toString();

            SendMessageRequest sendMsgRequest = SendMessageRequest.builder()
                    .queueUrl(queueUrl)
                    .messageBody(messageBody)
                    .messageGroupId(messageGroupId)
                    .messageDeduplicationId(messageDeduplicationId)
                    .build();


            sqsClient.sendMessage(sendMsgRequest);
        } catch (Exception e) {
            System.err.println("Error enviando mensaje a SQS: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private Map<String, Object> createKafkaMetadata(SinkRecord record) {
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("topic", record.topic());
        metadata.put("partition", record.kafkaPartition());
        metadata.put("offset", record.kafkaOffset());
        metadata.put("timestamp", record.timestamp());
        metadata.put("timestampType", record.timestampType() != null ? record.timestampType().toString() : null);

        if (record.key() != null) {
            metadata.put("key", record.key().toString());
        }

        return metadata;
    }

    @Override
    public void stop() {
        if (sqsClient != null) {
            sqsClient.close();
        }
        if (upsilonClient != null) {
            try {
                upsilonClient.close();
            } catch (Exception e) {
                System.err.println("Error cerrando cliente Upsilon: " + e.getMessage());
            }
        }

        // Cerrar el executor programado
        if (scheduledExecutor != null) {
            System.out.println("🔄 Cerrando executor de envíos diferidos...");
            scheduledExecutor.shutdown();
            try {
                if (!scheduledExecutor.awaitTermination(30, TimeUnit.SECONDS)) {
                    scheduledExecutor.shutdownNow();
                    System.out.println("⚠️ Executor forzado a cerrar");
                }
            } catch (InterruptedException e) {
                scheduledExecutor.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }
}
