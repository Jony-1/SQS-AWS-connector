package org.example.kafkaSQS;

import org.apache.kafka.common.config.AbstractConfig;
import org.apache.kafka.common.config.ConfigDef;

import java.util.Map;

public class SqsConnectorConfig extends AbstractConfig {

    public static final String SQS_QUEUE_URL = "sqs.queue.url";  // URL completa de la cola SQS
    public static final String SQS_QUEUE_NAME = "sqs.queue.name";
    public static final String AWS_ACCESS_KEY = "aws.access.key";
    public static final String AWS_SECRET_KEY = "aws.secret.key";
    public static final String AWS_REGION = "aws.region";  // Región de AWS
    public static final String KAFKA_TOPICS = "topics";  // Lista de tópicos de Kafka
    public static final String UPSILON_TOPICS = "upsilon.topics";  // Lista de tópicos que van a Upsilon
    public static final String UPSILON_ENDPOINT = "upsilon.endpoint";  // URL del endpoint Upsilon
    public static final String PROXY_HOST = "proxy.host";
    public static final String PROXY_PORT = "proxy.port";

    // Configuraciones para Upsilon Streams
    public static final String UPSILON_BASE_URL = "upsilon.base.url";  // URL base de Upsilon
    public static final String UPSILON_NAMESPACE = "upsilon.namespace";  // Namespace Upsilon
    public static final String UPSILON_STREAM_ID = "upsilon.stream.id";  // ID del stream Upsilon
    public static final String UPSILON_RECORD_TYPE_ID = "upsilon.record.type.id";  // Tipo de registro Upsilon
    public static final String UPSILON_AUTH_TOKEN = "upsilon.auth.token";  // Token de autorización
    public static final String UPSILON_ENABLED = "upsilon.enabled";  // Habilitar/deshabilitar envío a Upsilon
    public static final String UPSILON_STORE = "upsilon.store";  // Store específico (standard, monitoring, etc.)
    public static final String SQS_DELAY_MINUTES = "sqs.delay.minutes";  // Tiempo de retraso para envío a SQS (en minutos)

    public SqsConnectorConfig(Map<String, String> originals) {
        super(config(), originals);
    }

    public static ConfigDef config() {
        return new ConfigDef()
                .define(SQS_QUEUE_URL, ConfigDef.Type.STRING, null, ConfigDef.Importance.MEDIUM, "Complete SQS Queue URL (optional)")
                .define(SQS_QUEUE_NAME, ConfigDef.Type.STRING, null, ConfigDef.Importance.MEDIUM, "Name of the SQS Queue (used if URL is not provided)")
                .define(AWS_ACCESS_KEY, ConfigDef.Type.STRING, null, ConfigDef.Importance.MEDIUM, "AWS Access Key (optional)")
                .define(AWS_SECRET_KEY, ConfigDef.Type.STRING, null, ConfigDef.Importance.MEDIUM, "AWS Secret Key (optional)")
                .define(AWS_REGION, ConfigDef.Type.STRING, "us-east-1", ConfigDef.Importance.MEDIUM, "AWS Region (optional)")
                .define(KAFKA_TOPICS, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH, "Comma-separated list of Kafka topics to read from or write to")
                .define(UPSILON_TOPICS, ConfigDef.Type.STRING, null, ConfigDef.Importance.MEDIUM, "Comma-separated list of Upsilon topics")
                .define(UPSILON_ENDPOINT, ConfigDef.Type.STRING, null, ConfigDef.Importance.MEDIUM, "Upsilon endpoint URL")
                .define(PROXY_HOST, ConfigDef.Type.STRING, null, ConfigDef.Importance.LOW, "Proxy host for AWS connections")
                .define(PROXY_PORT, ConfigDef.Type.INT, null, ConfigDef.Importance.LOW, "Proxy port for AWS connections")
                .define(UPSILON_BASE_URL, ConfigDef.Type.STRING, null, ConfigDef.Importance.MEDIUM, "Base URL for Upsilon")
                .define(UPSILON_NAMESPACE, ConfigDef.Type.STRING, null, ConfigDef.Importance.MEDIUM, "Namespace for Upsilon")
                .define(UPSILON_STREAM_ID, ConfigDef.Type.STRING, null, ConfigDef.Importance.MEDIUM, "Stream ID for Upsilon")
                .define(UPSILON_RECORD_TYPE_ID, ConfigDef.Type.STRING, null, ConfigDef.Importance.MEDIUM, "Record type ID for Upsilon")
                .define(UPSILON_AUTH_TOKEN, ConfigDef.Type.STRING, null, ConfigDef.Importance.MEDIUM, "Authorization token for Upsilon")
                .define(UPSILON_ENABLED, ConfigDef.Type.BOOLEAN, true, ConfigDef.Importance.MEDIUM, "Enable or disable sending to Upsilon")
                .define(UPSILON_STORE, ConfigDef.Type.STRING, "standard", ConfigDef.Importance.LOW, "Upsilon store type (standard, monitoring, etc.)")
                .define(SQS_DELAY_MINUTES, ConfigDef.Type.INT, 5, ConfigDef.Importance.MEDIUM, "Delay in minutes before sending to SQS for Upsilon topics (default: 5)");
    }

}
