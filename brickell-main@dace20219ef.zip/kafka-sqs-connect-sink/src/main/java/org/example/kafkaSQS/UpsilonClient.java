package org.example.kafkaSQS;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.hc.client5.http.classic.methods.HttpDelete;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.classic.methods.HttpPatch;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Cliente para interactuar con Upsilon Streams de BBVA
 * Reemplaza la funcionalidad PSI con Upsilon para streaming de datos governado
 */
public class UpsilonClient {

    private static final Logger logger = LoggerFactory.getLogger(UpsilonClient.class);

    private final String baseUrl; // URL base de Upsilon (ej: https://upsilon.work-01.platform.bbva.com/v1)
    private final String namespace; // Namespace Upsilon
    private final String streamId; // ID del stream
    private final String recordTypeId; // Tipo de registro
    private final String authToken;
    private final CloseableHttpClient httpClient;
    private final ObjectMapper objectMapper;

    // Clases para respuesta batch
    public static class FailMessage {
        private String cause; private int code;
        public String getCause() { return cause; }
        public int getCode() { return code; }
        public void setCause(String cause) { this.cause = cause; }
        public void setCode(int code) { this.code = code; }
    }
    public static class InsertBatchResult {
        private int inserted; private List<Map<String,Object>> failedRecords; private List<FailMessage> failMessages;
        public int getInserted() { return inserted; }
        public List<Map<String,Object>> getFailedRecords() { return failedRecords; }
        public List<FailMessage> getFailMessages() { return failMessages; }
        public boolean allOk() { return failedRecords == null || failedRecords.isEmpty(); }
    }

    public UpsilonClient(String baseUrl, String namespace, String streamId, String recordTypeId, String authToken) {
        this.baseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        this.namespace = namespace;
        this.streamId = streamId;
        this.recordTypeId = recordTypeId;
        this.authToken = authToken;
        this.httpClient = HttpClients.createDefault();
        this.objectMapper = new ObjectMapper();
    }

    /**
     * Constructor legacy para compatibilidad hacia atrás
     */
    public UpsilonClient(String streamEndpoint, String authToken) {
        // Extraer componentes del endpoint para mantener compatibilidad
        // Formato esperado: https://upsilon.work-01.platform.bbva.com/v1/ns/{namespace}/streams/{stream}
        String[] parts = streamEndpoint.split("/");
        if (parts.length < 9) {
            throw new IllegalArgumentException("URL format invalid. Expected: https://host/v1/ns/{namespace}/streams/{stream}");
        }
        this.baseUrl = String.join("/", parts[0], parts[1], parts[2], parts[3], parts[4]); // hasta /v1
        this.namespace = parts[6]; // después de /ns/
        this.streamId = parts[8]; // después de /streams/
        this.recordTypeId = null; // No disponible en URL legacy
        this.authToken = authToken;
        this.httpClient = HttpClients.createDefault();
        this.objectMapper = new ObjectMapper();
    }

    /**
     * RECORD TYPES - Gestión de esquemas
     */

    /**
     * Crea un record type usando JSON - Versión mejorada con soporte completo para esquemas Upsilon
     */
    public boolean createRecordType(String recordTypeId, Map<String, Object> schema, String description) {
        try {
            String endpoint = String.format("%s/ns/%s/record-types", baseUrl, namespace);

            Map<String, Object> payload = new HashMap<>();
            payload.put("_id", recordTypeId);
            payload.put("protoSpec", schema);
            if (description != null && !description.isEmpty()) payload.put("description", description);
            String jsonPayload = objectMapper.writeValueAsString(payload);
            return sendRequest(endpoint, jsonPayload);

        } catch (Exception e) {
            logger.error("⚠️ Error creando record type", e);
            return false;
        }
    }

    /**
     * Crea un record type simple con campos básicos
     */
    public boolean createSimpleRecordType(String recordTypeId, Map<String, String> fields, String description) {
        Map<String, Object> schema = new HashMap<>();
        fields.forEach(schema::put);
        return createRecordType(recordTypeId, schema, description);
    }

    /**
     * Builder para crear esquemas complejos de Upsilon
     */
    public static class SchemaBuilder {
        private final Map<String, Object> schema = new HashMap<>();

        /**
         * Añade un campo de tipo básico
         * Tipos soportados: double, float, int32, int64, uint32, uint64, sint32, sint64,
         * fixed32, fixed64, bool, string, bytes
         */
        public SchemaBuilder addField(String fieldName, String type) {
            schema.put(fieldName, type);
            return this;
        }

        /**
         * Añade un campo de tipo array
         */
        public SchemaBuilder addArrayField(String fieldName, String elementType) {
            schema.put(fieldName, "[]" + elementType);
            return this;
        }

        /**
         * Añade un tipo message (objeto complejo)
         */
        public SchemaBuilder addMessageType(String typeName, Map<String, Object> messageFields) {
            Map<String, Object> messageType = new HashMap<>();
            messageType.put("message", messageFields);
            schema.put(typeName, messageType);
            return this;
        }

        /**
         * Añade un campo que usa un tipo message
         */
        public SchemaBuilder addMessageField(String fieldName, String messageTypeName) {
            schema.put(fieldName, messageTypeName);
            return this;
        }

        /**
         * Añade un tipo enum
         */
        public SchemaBuilder addEnumType(String typeName, String... enumValues) {
            Map<String, Object> enumType = new HashMap<>();
            enumType.put("enum", List.of(enumValues));
            schema.put(typeName, enumType);
            return this;
        }

        /**
         * Añade un campo que usa un tipo enum
         */
        public SchemaBuilder addEnumField(String fieldName, String enumTypeName) {
            schema.put(fieldName, enumTypeName);
            return this;
        }

        /**
         * Añade un tipo map
         */
        public SchemaBuilder addMapType(String typeName, String keyType, String valueType) {
            Map<String, Object> mapType = new HashMap<>();
            Map<String, String> mapSpec = new HashMap<>();
            mapSpec.put(keyType, valueType);
            mapType.put("map", mapSpec);
            schema.put(typeName, mapType);
            return this;
        }

        /**
         * Añade un campo de tipo map directo
         */
        public SchemaBuilder addMapField(String fieldName, String keyType, String valueType) {
            Map<String, Object> mapType = new HashMap<>();
            Map<String, String> mapSpec = new HashMap<>();
            mapSpec.put(keyType, valueType);
            mapType.put("map", mapSpec);
            schema.put(fieldName, mapType);
            return this;
        }

        /**
         * Añade un tipo oneOf
         */
        public SchemaBuilder addOneOfType(String typeName, Map<String, String> oneOfFields) {
            Map<String, Object> oneOfType = new HashMap<>();
            oneOfType.put("oneof", oneOfFields);
            schema.put(typeName, oneOfType);
            return this;
        }

        /**
         * Añade un campo que usa un tipo oneOf
         */
        public SchemaBuilder addOneOfField(String fieldName, String oneOfTypeName) {
            schema.put(fieldName, oneOfTypeName);
            return this;
        }

        /**
         * Construye el esquema
         */
        public Map<String, Object> build() {
            return new HashMap<>(schema);
        }
    }

    /**
     * Métodos helper para crear esquemas comunes
     */

    /**
     * Crea un record type para eventos simples con cardId
     */
    public boolean createCardEventRecordType(String recordTypeId, String description) {
        SchemaBuilder builder = new SchemaBuilder()
            .addField("cardId", "string");

        return createRecordType(recordTypeId, builder.build(), description);
    }

    /**
     * Crea un record type para eventos de salud de servicios
     */
    public boolean createHealthEventRecordType(String recordTypeId, String description) {
        // Definir tipo health como message
        Map<String, Object> healthFields = new HashMap<>();
        healthFields.put("timestamp", "string");
        healthFields.put("duration", "int64");
        healthFields.put("status", "string");

        SchemaBuilder builder = new SchemaBuilder()
            .addMessageType("health", healthFields)
            .addMessageField("serviceStatus", "health");

        return createRecordType(recordTypeId, builder.build(), description);
    }

    /**
     * Crea un record type para eventos de familia con enum
     */
    public boolean createFamilyEventRecordType(String recordTypeId, String description) {
        SchemaBuilder builder = new SchemaBuilder()
            .addEnumType("family", "FATHER", "MOTHER", "SON", "DAUGHTER")
            .addEnumField("person", "family");

        return createRecordType(recordTypeId, builder.build(), description);
    }

    /**
     * Crea un record type complejo con múltiples tipos
     */
    public boolean createComplexEventRecordType(String recordTypeId, String description) {
        // Tipo family (enum)
        SchemaBuilder builder = new SchemaBuilder()
            .addEnumType("family", "FATHER", "MOTHER", "SON", "DAUGHTER");

        // Tipo number con oneOf anidado
        Map<String, String> oneOfFields = new HashMap<>();
        oneOfFields.put("integerShort", "int32");
        oneOfFields.put("integerLong", "int64");
        oneOfFields.put("floating", "double");

        Map<String, Object> numberInternalFields = new HashMap<>();
        numberInternalFields.put("number_internal", Map.of("oneof", oneOfFields));

        builder.addMessageType("number", numberInternalFields);

        // Tipo health (message)
        Map<String, Object> healthFields = new HashMap<>();
        healthFields.put("timestamp", "string");
        healthFields.put("duration", "int64");
        healthFields.put("status", "string");

        builder.addMessageType("health", healthFields);

        // Campos finales
        builder.addMessageField("serviceStatus", "health")
               .addMessageField("cardId", "number")
               .addEnumField("person", "family");

        return createRecordType(recordTypeId, builder.build(), description);
    }

    /**
     * Crea un record type para contactos con mensajes anidados
     */
    public boolean createContactRecordType(String recordTypeId, String description) {
        // Tipo locationKind
        Map<String, Object> locationFields = new HashMap<>();
        locationFields.put("street", "string");
        locationFields.put("number", "uint32");

        // Tipo contactKind
        Map<String, Object> contactFields = new HashMap<>();
        contactFields.put("location", "locationKind");
        contactFields.put("phone_number", "string");
        contactFields.put("email", "string");

        SchemaBuilder builder = new SchemaBuilder()
            .addMessageType("locationKind", locationFields)
            .addMessageType("contactKind", contactFields)
            .addMessageField("contact", "contactKind")
            .addField("name", "string");

        return createRecordType(recordTypeId, builder.build(), description);
    }

    /**
     * Crea un record type para alertas con arrays
     */
    public boolean createAlertsRecordType(String recordTypeId, String description) {
        // Tipo eventModel
        Map<String, Object> eventFields = new HashMap<>();
        eventFields.put("instantQuote", "double");
        eventFields.put("referenceQuote", "double");
        eventFields.put("instantFluctuation", "double");
        eventFields.put("registrationDate", "string");
        eventFields.put("alertTypeId", "string");
        eventFields.put("AlertTypeDescription", "string");

        // Tipo alertModel
        Map<String, Object> alertFields = new HashMap<>();
        alertFields.put("key", "string");
        alertFields.put("values", "eventModel");

        SchemaBuilder builder = new SchemaBuilder()
            .addMessageType("eventModel", eventFields)
            .addMessageType("alertModel", alertFields)
            .addArrayField("alerts", "alertModel");

        return createRecordType(recordTypeId, builder.build(), description);
    }

    /**
     * Crea un record type con headers de tipo map
     */
    public boolean createHeadersRecordType(String recordTypeId, String description) {
        SchemaBuilder builder = new SchemaBuilder()
            .addMapField("headers", "string", "string")
            .addField("messageId", "string")
            .addField("timestamp", "int64");

        return createRecordType(recordTypeId, builder.build(), description);
    }

    /**
     * Crea un record type usando archivo Protobuf
     */
    public boolean createRecordTypeByProto(String recordTypeId, String protoContent, String description) {
        try {
            String endpoint = String.format("%s/ns/%s/record-types/%s:createByProto",
                                           baseUrl, namespace, recordTypeId);

            return sendPlainTextRequest(endpoint, protoContent, description);

        } catch (Exception e) {
            logger.error("⚠️ Error creando record type por proto", e);
            return false;
        }
    }

    /**
     * Lista record types disponibles
     */
    public String listRecordTypes() {
        String endpoint = String.format("%s/ns/%s/record-types", baseUrl, namespace);
        return sendGetRequest(endpoint);
    }

    /**
     * Obtiene un record type específico
     */
    public String getRecordType(String recordTypeId) {
        String endpoint = String.format("%s/ns/%s/record-types/%s", baseUrl, namespace, recordTypeId);
        return sendGetRequest(endpoint);
    }

    /**
     * Elimina un record type
     */
    public boolean deleteRecordType(String recordTypeId) {
        String endpoint = String.format("%s/ns/%s/record-types/%s", baseUrl, namespace, recordTypeId);
        return sendDeleteRequest(endpoint);
    }

    /**
     * STREAMS - Gestión de flujos de datos
     */

    /**
     * Crea un stream de Upsilon
     */
    public boolean createStream(String streamId, String recordTypeLocator, String description, String store) {
        try {
            String endpoint = String.format("%s/ns/%s/streams", baseUrl, namespace);

            Map<String, Object> payload = new HashMap<>();
            payload.put("_id", streamId);
            payload.put("recordType", recordTypeLocator);

            if (description != null && !description.isEmpty()) {
                payload.put("description", description);
            }

            if (store != null && !store.isEmpty()) {
                payload.put("store", store);
            }

            String jsonPayload = objectMapper.writeValueAsString(payload);
            return sendRequest(endpoint, jsonPayload);

        } catch (Exception e) {
            logger.error("⚠️ Error creando stream", e);
            return false;
        }
    }

    /**
     * putRecord retrocompatible (boolean) pero ahora captura y loggea offset
     */
    public boolean putRecord(Map<String, Object> data) {
        Long off = putRecordReturnOffset(data);
        return off != null;
    }

    /**
     * Envía un registro y devuelve offset (null si error)
     */
    public Long putRecordReturnOffset(Map<String,Object> data) {
        try {
            String endpoint = String.format("%s/ns/%s/streams/%s:putRecord", baseUrl, namespace, streamId);
            HttpResponseWrapper resp = sendPostForBody(endpoint, objectMapper.writeValueAsString(data));
            if (resp.success()) {
                try {
                    JsonNode node = objectMapper.readTree(resp.body());
                    if (node.has("offset")) {
                        long off = node.get("offset").asLong();
                        logger.info("✅ Registro insertado offset={}", off);
                        return off;
                    }
                    logger.warn("⚠️ Respuesta sin offset: {}", resp.body());
                } catch (Exception ex) { logger.error("⚠️ Error parseando offset: {}", resp.body(), ex); }
            } else {
                logger.error("❌ putRecord fallo status={} body={}", resp.statusCode, resp.body());
            }
        } catch (Exception e) { logger.error("⚠️ Error enviando registro", e); }
        return null;
    }

    /**
     * Versión parseada de batch (estructura InsertBatchResult)
     */
    public InsertBatchResult putRecordBatchParsed(List<Map<String,Object>> records) {
        try {
            String endpoint = String.format("%s/ns/%s/streams/%s:putRecordBatch", baseUrl, namespace, streamId);
            HttpResponseWrapper resp = sendPostForBody(endpoint, objectMapper.writeValueAsString(Map.of("records", records)));
            if (resp.success()) {
                try {
                    InsertBatchResult r = objectMapper.readValue(resp.body(), InsertBatchResult.class);
                    if (r.allOk()) logger.info("✅ Batch OK inserted={}", r.getInserted());
                    else logger.warn("⚠️ Batch parcial inserted={} failed={}", r.getInserted(), r.getFailedRecords()==null?0:r.getFailedRecords().size());
                    return r;
                } catch (Exception ex) { logger.error("⚠️ Error parseando respuesta batch: {}", resp.body(), ex); return null; }
            } else {
                logger.error("❌ putRecordBatch fallo status={} body={}", resp.statusCode, resp.body());
            }
        } catch (Exception e) { logger.error("⚠️ Error enviando batch", e); }
        return null;
    }

    /**
     * Obtiene registros del stream
     */
    public String getRecords(long fromOffset, int timeout, int limit) {
        try {
            Map<String,Object> payload = Map.of("from", fromOffset, "timeout", timeout, "limit", limit);
            return sendPostRequest(String.format("%s/ns/%s/streams/%s:getRecords", baseUrl, namespace, streamId), objectMapper.writeValueAsString(payload));
        } catch (Exception e) { logger.error("⚠️ Error obteniendo registros", e); return null; }
    }

    /**
     * Lista streams disponibles
     */
    public String listStreams() {
        String endpoint = String.format("%s/ns/%s/streams", baseUrl, namespace);
        return sendGetRequest(endpoint);
    }

    /**
     * Obtiene información de un stream específico
     */
    public String getStream(String streamId) {
        String endpoint = String.format("%s/ns/%s/streams/%s", baseUrl, namespace, streamId);
        return sendGetRequest(endpoint);
    }

    /**
     * Obtiene la longitud (número de registros) del stream
     */
    public String getStreamLength() {
        String endpoint = String.format("%s/ns/%s/streams/%s:getLen", baseUrl, namespace, streamId);
        return sendPostRequest(endpoint, "{}");
    }

    /**
     * Obtiene metadatos del stream (first/last offset, datetime, length)
     */
    public String getStreamMetadata() {
        String endpoint = String.format("%s/ns/%s/streams/%s:getMetadata", baseUrl, namespace, streamId);
        return sendPostRequest(endpoint, "{}");
    }

    /**
     * Envía múltiples registros en lote al stream
     */
    public String putRecordBatch(List<Map<String, Object>> records) {
        try {
            String endpoint = String.format("%s/ns/%s/streams/%s:putRecordBatch",
                                           baseUrl, namespace, streamId);

            Map<String, Object> payload = Map.of("records", records);
            String jsonPayload = objectMapper.writeValueAsString(payload);

            return sendPostRequest(endpoint, jsonPayload);

        } catch (Exception e) {
            logger.error("⚠️ Error al serializar batch de registros para Upsilon", e);
            return null;
        }
    }

    /**
     * Establece el tamaño máximo de registros en KB
     */
    public boolean setRecordMaxKBs(int maxKBs) {
        try {
            String endpoint = String.format("%s/ns/%s/streams/%s:setRecordMaxKBs",
                                           baseUrl, namespace, streamId);

            Map<String, Integer> payload = Map.of("recordMaxKBs", maxKBs);
            String jsonPayload = objectMapper.writeValueAsString(payload);
            return sendRequest(endpoint, jsonPayload);

        } catch (Exception e) {
            logger.error("⚠️ Error estableciendo tamaño máximo de registros", e);
            return false;
        }
    }

    /**
     * Establece política TTL para el stream
     */
    public boolean setTTLPolicy(int ttl, String unit) {
        try {
            String endpoint = String.format("%s/ns/%s/streams/%s:setTTLPolicy",
                                           baseUrl, namespace, streamId);

            Map<String, Object> payload = new HashMap<>();
            payload.put("ttl", ttl);
            if (unit != null && !unit.isEmpty()) {
                payload.put("unit", unit); // day, hour, minute
            }

            String jsonPayload = objectMapper.writeValueAsString(payload);
            return sendRequest(endpoint, jsonPayload);

        } catch (Exception e) {
            logger.error("⚠️ Error estableciendo política TTL", e);
            return false;
        }
    }

    /**
     * Establece política TTL (solo días - por defecto)
     */
    public boolean setTTLPolicy(int days) {
        return setTTLPolicy(days, "day");
    }

    /**
     * Deshabilita política TTL
     */
    public boolean disableTTL() {
        return setTTLPolicy(0, null);
    }

    /**
     * Establece almacenamiento en frío usando Epsilon
     */
    public boolean setColdStorage(String epsilonBucketLocator, int executionFrequencyMinutes,
                                String format, String compression, Integer minRecords, Integer maxRecords) {
        try {
            String endpoint = String.format("%s/ns/%s/streams/%s:setColdStorage",
                                           baseUrl, namespace, streamId);

            Map<String, Object> payload = new HashMap<>();
            payload.put("locator", epsilonBucketLocator);
            payload.put("executionFrequency", executionFrequencyMinutes);

            if (format != null) payload.put("format", format); // json, csv, proto
            if (compression != null) payload.put("compression", compression); // gzip, bzip2
            if (minRecords != null) payload.put("minRecords", minRecords);
            if (maxRecords != null) payload.put("maxRecords", maxRecords);

            String jsonPayload = objectMapper.writeValueAsString(payload);
            return sendRequest(endpoint, jsonPayload);

        } catch (Exception e) {
            logger.error("⚠️ Error configurando almacenamiento en frío", e);
            return false;
        }
    }

    /**
     * Elimina configuración de almacenamiento en frío
     */
    public boolean unsetColdStorage() {
        String endpoint = String.format("%s/ns/%s/streams/%s:unsetColdStorage",
                                       baseUrl, namespace, streamId);
        return sendRequest(endpoint, "POST", "{}");
    }

    /**
     * Obtiene información de discovery del stream (endpoints HTTP/gRPC)
     */
    public String discovery() {
        String endpoint = String.format("%s/ns/%s/streams/%s:discovery",
                                       baseUrl, namespace, streamId);
        return sendPostRequest(endpoint, "{}");
    }

    /**
     * Establece el offset para un grupo de consumidores
     */
    public boolean setGroupIdOffset(String groupId, long offset) {
        try {
            String endpoint = String.format("%s/ns/%s/streams/%s:setGroupIdOffset",
                                           baseUrl, namespace, streamId);

            Map<String, Object> payload = Map.of(
                "groupId", groupId,
                "offset", offset
            );

            String jsonPayload = objectMapper.writeValueAsString(payload);
            return sendRequest(endpoint, jsonPayload);

        } catch (Exception e) {
            logger.error("⚠️ Error estableciendo offset de grupo", e);
            return false;
        }
    }

    /**
     * Elimina un stream
     */
    public boolean deleteStream(String streamIdToDelete) {
        String endpoint = String.format("%s/ns/%s/streams/%s", baseUrl, namespace, streamIdToDelete);
        return sendDeleteRequest(endpoint);
    }

    /**
     * Obtiene registros con grupo de consumidores
     */
    public String getRecordsWithGroup(String groupId, int timeout, int limit) {
        try {
            Map<String,Object> p=new HashMap<>(); p.put("groupId",groupId); p.put("timeout",timeout); if(limit>0)p.put("limit",limit);
            return sendPostRequest(String.format("%s/ns/%s/streams/%s:getRecords", baseUrl, namespace, streamId), objectMapper.writeValueAsString(p));
        } catch(Exception e){ logger.error("⚠️ Error getRecordsWithGroup", e); return null;} }
    public String getRecordsWithLast(boolean last, int timeout, int limit) {
        try {
            Map<String,Object> p=new HashMap<>(); p.put("last",last); p.put("timeout",timeout); if(limit>0)p.put("limit",limit);
            return sendPostRequest(String.format("%s/ns/%s/streams/%s:getRecords", baseUrl, namespace, streamId), objectMapper.writeValueAsString(p));
        } catch(Exception e){ logger.error("⚠️ Error getRecordsWithLast", e); return null;} }
    /**
     * Actualiza un record type usando Protobuf (solo agregar campos)
     */
    public boolean patchRecordType(String recordTypeId, String protoContent, String description) {
        try {
            String endpoint = String.format("%s/ns/%s/record-types/%s",
                                           baseUrl, namespace, recordTypeId);

            return sendPatchRequest(endpoint, protoContent, description);

        } catch (Exception e) {
            logger.error("⚠️ Error actualizando record type", e);
            return false;
        }
    }

    /**
     * Obtiene la definición Protobuf de un record type
     */
    public String getRecordTypeProto(String recordTypeId) {
        String endpoint = String.format("%s/ns/%s/record-types/%s:getProto",
                                       baseUrl, namespace, recordTypeId);
        return sendPostRequest(endpoint, "{}");
    }

    /**
     * Obtiene el descriptor de archivo Protobuf
     */
    public String getRecordTypeFileDescriptor(String recordTypeId) {
        String endpoint = String.format("%s/ns/%s/record-types/%s:getFD",
                                       baseUrl, namespace, recordTypeId);
        return sendPostRequest(endpoint, "{}");
    }

    /**
     * Obtiene stub de código para serialización
     */
    public String getRecordTypeStub(String recordTypeId, String language) {
        try {
            String endpoint = String.format("%s/ns/%s/record-types/%s:getStub",
                                           baseUrl, namespace, recordTypeId);

            Map<String, String> payload = Map.of("language", language); // java, go, js, python
            String jsonPayload = objectMapper.writeValueAsString(payload);
            return sendPostRequest(endpoint, jsonPayload);

        } catch (Exception e) {
            logger.error("⚠️ Error obteniendo stub", e);
            return null;
        }
    }

    /**
     * MÉTODOS AUXILIARES
     */

    /**
     * Método genérico para enviar requests HTTP POST
     * NOTA: Parámetro 'method' no se usa (siempre POST) - mantenido para compatibilidad
     */
    private boolean sendRequest(String endpoint, String jsonPayload) {
        try {
            HttpPost httpPost = new HttpPost(endpoint);
            httpPost.setHeader("Content-Type", "application/json");
            httpPost.setHeader("Accept", "application/json");
            if (authToken != null && !authToken.isEmpty()) {
                httpPost.setHeader("Authorization", "Bearer " + authToken);
            }
            if (jsonPayload != null && !jsonPayload.isEmpty()) {
                httpPost.setEntity(new StringEntity(jsonPayload, ContentType.APPLICATION_JSON));
            }
            try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
                int statusCode = response.getCode();
                String body = safeReadBody(response);
                if (statusCode >= 200 && statusCode < 300) {
                    logger.info("✅ Operación Upsilon exitosa. Status={} Endpoint={}", statusCode, endpoint);
                    return true;
                } else {
                    logger.error("❌ Error Upsilon. Status={} Endpoint={} Body={}", statusCode, endpoint, body);
                    return false;
                }
            }
        } catch (IOException e) { logger.error("⚠️ Error de conexión en Upsilon. Endpoint: {}", endpoint, e); return false; }
        catch (Exception e) { logger.error("⚠️ Error inesperado en Upsilon. Endpoint: {}", endpoint, e); return false; }
    }

    /**
     * Wrapper para compatibilidad con firma antigua
     */
    private boolean sendRequest(String endpoint, String method, String jsonPayload) {
        return sendRequest(endpoint, jsonPayload);
    }

    /**
     * Método para requests con contenido text/plain (para protobuf)
     * NOTA: Parámetro 'method' no se usa (siempre POST) - mantenido para compatibilidad
     */
    private boolean sendPlainTextRequest(String endpoint, String content, String description) {
        try {
            HttpPost httpPost = new HttpPost(endpoint);
            httpPost.setHeader("Content-Type", "text/plain");
            httpPost.setHeader("Accept", "application/json");
            if (description != null && !description.isEmpty()) httpPost.setHeader("X-Description", description);
            if (authToken != null && !authToken.isEmpty()) httpPost.setHeader("Authorization", "Bearer " + authToken);
            if (content != null && !content.isEmpty()) httpPost.setEntity(new StringEntity(content, ContentType.TEXT_PLAIN));
            try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
                int statusCode = response.getCode();
                String body = safeReadBody(response);
                if (statusCode >= 200 && statusCode < 300) {
                    logger.info("✅ Operación Upsilon protobuf exitosa. Endpoint: {}, Status: {}", endpoint, statusCode);
                    return true;
                } else {
                    logger.error("❌ Error en operación protobuf. Endpoint: {}, Status: {} Body={}", endpoint, statusCode, body);
                    return false;
                }
            }
        } catch (IOException e) { logger.error("⚠️ Error de conexión protobuf. Endpoint: {}", endpoint, e); return false; }
        catch (Exception e) { logger.error("⚠️ Error inesperado protobuf. Endpoint: {}", endpoint, e); return false; }
    }

    /**
     * Wrapper para compatibilidad con firma antigua
     */
    private boolean sendPlainTextRequest(String endpoint, String method, String content, String description) {
        return sendPlainTextRequest(endpoint, content, description);
    }

    /**
     * Método genérico para requests GET
     */
    private String sendGetRequest(String endpoint) {
        try {
            HttpGet httpGet = new HttpGet(endpoint);

            // Headers obligatorios
            httpGet.setHeader("Accept", "application/json");

            if (authToken != null && !authToken.isEmpty()) httpGet.setHeader("Authorization", "Bearer " + authToken);
            try (CloseableHttpResponse response = httpClient.execute(httpGet)) {
                int statusCode = response.getCode();
                String responseBody = safeReadBody(response);
                if (statusCode >= 200 && statusCode < 300) { logger.info("✅ GET Upsilon exitoso. Endpoint: {}, Status: {}", endpoint, statusCode); return responseBody; }
                else { logger.error("❌ Error GET Upsilon. Endpoint: {}, Status: {} Body={}", endpoint, statusCode, responseBody); return null; }
            }
        } catch (Exception e) { logger.error("⚠️ Error en GET Upsilon. Endpoint: {}", endpoint, e); return null; }
    }

    /**
     * Método genérico para requests POST que retornan contenido
     */
    private String sendPostRequest(String endpoint, String jsonPayload) {
        try {
            HttpPost httpPost = new HttpPost(endpoint);

            // Headers obligatorios
            httpPost.setHeader("Content-Type", "application/json");
            httpPost.setHeader("Accept", "application/json");

            if (authToken != null && !authToken.isEmpty()) httpPost.setHeader("Authorization", "Bearer " + authToken);
            if (jsonPayload != null && !jsonPayload.isEmpty()) httpPost.setEntity(new StringEntity(jsonPayload, ContentType.APPLICATION_JSON));
            try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
                int statusCode = response.getCode();
                String responseBody = safeReadBody(response);
                if (statusCode >= 200 && statusCode < 300) { logger.info("✅ POST Upsilon exitoso. Endpoint: {}, Status: {}", endpoint, statusCode); return responseBody; }
                else { logger.error("❌ Error POST Upsilon. Endpoint: {}, Status: {} Body={}", endpoint, statusCode, responseBody); return null; }
            }
        } catch (Exception e) { logger.error("⚠️ Error en POST Upsilon. Endpoint: {}", endpoint, e); return null; }
    }

    /**
     * Método genérico para requests DELETE
     */
    private boolean sendDeleteRequest(String endpoint) {
        try {
            HttpDelete httpDelete = new HttpDelete(endpoint);

            // Headers obligatorios
            httpDelete.setHeader("Accept", "application/json");

            if (authToken != null && !authToken.isEmpty()) httpDelete.setHeader("Authorization", "Bearer " + authToken);
            try (CloseableHttpResponse response = httpClient.execute(httpDelete)) {
                int statusCode = response.getCode();
                String body = safeReadBody(response);
                if (statusCode >= 200 && statusCode < 300) { logger.info("✅ DELETE Upsilon exitoso. Endpoint: {}, Status: {}", endpoint, statusCode); return true; }
                else { logger.error("❌ Error DELETE Upsilon. Endpoint: {}, Status: {} Body={}", endpoint, statusCode, body); return false; }
            }
        } catch (Exception e) { logger.error("⚠️ Error en DELETE Upsilon. Endpoint: {}", endpoint, e); return false; }
    }

    /**
     * Método genérico para requests PATCH (usado para actualizar record types)
     */
    private boolean sendPatchRequest(String endpoint, String protoContent, String description) {
        try {
            HttpPatch httpPatch = new HttpPatch(endpoint);

            // Headers para protobuf
            httpPatch.setHeader("Content-Type", "text/plain");
            httpPatch.setHeader("Accept", "application/json");

            if (description != null && !description.isEmpty()) httpPatch.setHeader("X-Description", description);
            if (authToken != null && !authToken.isEmpty()) httpPatch.setHeader("Authorization", "Bearer " + authToken);
            if (protoContent != null && !protoContent.isEmpty()) httpPatch.setEntity(new StringEntity(protoContent, ContentType.TEXT_PLAIN));
            try (CloseableHttpResponse response = httpClient.execute(httpPatch)) {
                int statusCode = response.getCode();
                String body = safeReadBody(response);
                if (statusCode >= 200 && statusCode < 300) { logger.info("✅ PATCH Upsilon exitoso. Endpoint: {}, Status: {}", endpoint, statusCode); return true; }
                else { logger.error("❌ Error PATCH Upsilon. Endpoint: {}, Status: {} Body={}", endpoint, statusCode, body); return false; }
            }
        } catch (IOException e) { logger.error("⚠️ Error conexión PATCH Upsilon. Endpoint: {}", endpoint, e); return false; }
        catch (Exception e) { logger.error("⚠️ Error inesperado PATCH Upsilon. Endpoint: {}", endpoint, e); return false; }
    }

    // Helpers HTTP específicos
    private static class HttpResponseWrapper { final int statusCode; final String body; HttpResponseWrapper(int c,String b){statusCode=c;body=b;} boolean success(){return statusCode>=200&&statusCode<300;} String body(){return body;} }
    private HttpResponseWrapper sendPostForBody(String endpoint, String jsonPayload) {
        HttpPost post = new HttpPost(endpoint);
        post.setHeader("Content-Type","application/json");
        post.setHeader("Accept","application/json");
        if (authToken!=null && !authToken.isEmpty()) post.setHeader("Authorization","Bearer "+authToken);
        if (jsonPayload!=null && !jsonPayload.isEmpty()) post.setEntity(new StringEntity(jsonPayload, ContentType.APPLICATION_JSON));
        try (CloseableHttpResponse r = httpClient.execute(post)) { return new HttpResponseWrapper(r.getCode(), safeReadBody(r)); }
        catch (Exception e){ logger.error("⚠️ Error POST {}", endpoint, e); return new HttpResponseWrapper(599, ""); }
    }
    private String safeReadBody(CloseableHttpResponse r) {
        try {
            if (r.getEntity()==null) return "";
            try(InputStream is=r.getEntity().getContent()){
                return new String(is.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch(Exception e){
            logger.debug("⚠️ Error leyendo response body", e);
            return "";
        }
    }

    public void close() { try { httpClient.close(); } catch (IOException e) { logger.warn("⚠️ Error al cerrar HTTP client", e);} }

    public String getBaseUrl() { return baseUrl; }
    public String getNamespace() { return namespace; }
    public String getStreamId() { return streamId; }
    public String getRecordTypeId() { return recordTypeId; }
}
