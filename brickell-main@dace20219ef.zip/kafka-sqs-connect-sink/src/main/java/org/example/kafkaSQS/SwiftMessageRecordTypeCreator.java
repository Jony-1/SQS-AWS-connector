package org.example.kafkaSQS;

import java.util.HashMap;
import java.util.Map;

/**
 * Utilitario para crear el Record Type específico para mensajes XML/SWIFT
 * procesados desde Kafka hacia Upsilon
 */
public class SwiftMessageRecordTypeCreator {

    /**
     * Crea el record type para mensajes SWIFT/XML procesados
     */
    public static boolean createSwiftMessageRecordType(UpsilonClient client) {
        try {
            // Definir el esquema para los datos extraídos del XML
            UpsilonClient.SchemaBuilder builder = new UpsilonClient.SchemaBuilder();

            // Campos principales del XML
            builder.addField("originalXml", "string")
                   .addField("extractedAt", "int64")
                   .addField("direction", "string")
                   .addField("protocol", "string")
                   .addField("senderAddress", "string")
                   .addField("receiverAddress", "string")
                   .addField("pdeIndication", "string")
                   .addField("userReference", "string")
                   .addField("requestType", "string")
                   .addField("requestSubType", "string")
                   .addField("requestPayloadType", "string");

            // Tipo ApplicationHeader (mensaje anidado)
            Map<String, Object> appHeaderFields = new HashMap<>();
            appHeaderFields.put("fromBICFI", "string");
            appHeaderFields.put("toBICFI", "string");
            appHeaderFields.put("bizMsgIdr", "string");
            appHeaderFields.put("msgDefIdr", "string");
            appHeaderFields.put("bizSvc", "string");
            appHeaderFields.put("creDt", "string");

            builder.addMessageType("applicationHeaderType", appHeaderFields)
                   .addMessageField("applicationHeader", "applicationHeaderType");

            // Tipo Debtor/Creditor (para reutilización)
            Map<String, Object> actorFields = new HashMap<>();
            actorFields.put("name", "string");
            actorFields.put("account", "string");
            actorFields.put("bicfi", "string");

            builder.addMessageType("actorType", actorFields);

            // Tipo PACS Data (mensaje complejo)
            Map<String, Object> pacsFields = new HashMap<>();
            pacsFields.put("msgId", "string");
            pacsFields.put("creDtTm", "string");
            pacsFields.put("nbOfTxs", "string");
            pacsFields.put("sttlmMtd", "string");
            pacsFields.put("instrId", "string");
            pacsFields.put("endToEndId", "string");
            pacsFields.put("uetr", "string");
            pacsFields.put("intrBkSttlmAmt", "string");
            pacsFields.put("instdAmt", "string");
            pacsFields.put("chrgsAmt", "string");
            pacsFields.put("intrBkSttlmDt", "string");
            pacsFields.put("chrgBr", "string");
            pacsFields.put("debtor", "actorType");
            pacsFields.put("creditor", "actorType");

            builder.addMessageType("pacsDataType", pacsFields)
                   .addMessageField("pacsData", "pacsDataType");

            // Tipo Kafka Metadata
            Map<String, Object> kafkaFields = new HashMap<>();
            kafkaFields.put("topic", "string");
            kafkaFields.put("partition", "int32");
            kafkaFields.put("offset", "int64");
            kafkaFields.put("timestamp", "int64");
            kafkaFields.put("timestampType", "string");
            kafkaFields.put("key", "string");

            builder.addMessageType("kafkaMetadataType", kafkaFields)
                   .addMessageField("kafkaMetadata", "kafkaMetadataType");

            // Tipo para campos personalizados (map)
            builder.addMapField("customFields", "string", "string");

            // Campos adicionales de metadatos
            builder.addField("processedAt", "int64")
                   .addField("sourceTopic", "string")
                   .addField("messageFormat", "string")
                   .addField("connectorOrigin", "string")
                   .addField("streamTimestamp", "int64");

            // Crear el record type
            Map<String, Object> schema = builder.build();
            boolean success = client.createRecordType(
                "SwiftMessageRecord",
                schema,
                "Esquema para mensajes SWIFT/XML procesados desde Kafka"
            );

            if (success) {
                System.out.println("✅ Record Type 'SwiftMessageRecord' creado exitosamente");
                return true;
            } else {
                System.err.println("❌ Error creando Record Type 'SwiftMessageRecord'");
                return false;
            }

        } catch (Exception e) {
            System.err.println("⚠️ Error en creación del Record Type: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Crea el stream para los mensajes SWIFT
     */
    public static boolean createSwiftMessageStream(UpsilonClient client) {
        boolean success = client.createStream(
            "kafka-xml-messages",
            "SwiftMessageRecord",
            "Stream para mensajes XML/SWIFT procesados desde Kafka",
            "standard"
        );

        if (success) {
            System.out.println("✅ Stream 'kafka-xml-messages' creado exitosamente");
        } else {
            System.err.println("❌ Error creando Stream 'kafka-xml-messages'");
        }

        return success;
    }

    /**
     * Setup completo: crea record type y stream
     */
    public static boolean setupSwiftMessageUpsilon(String baseUrl, String namespace, String authToken) {
        UpsilonClient client = new UpsilonClient(baseUrl, namespace, null, null, authToken);

        try {
            System.out.println("🚀 Configurando Upsilon para mensajes SWIFT...");

            // 1. Crear Record Type
            boolean rtSuccess = createSwiftMessageRecordType(client);
            if (!rtSuccess) {
                return false;
            }

            // 2. Crear Stream
            boolean streamSuccess = createSwiftMessageStream(client);
            if (!streamSuccess) {
                return false;
            }

            System.out.println("✅ Setup completo de Upsilon para mensajes SWIFT");
            return true;

        } finally {
            client.close();
        }
    }

    /**
     * Método main para ejecutar el setup
     */
    public static void main(String[] args) {
        // Configurar estos valores según tu entorno
        String baseUrl = "https://upsilon.work-01.platform.bbva.com/v1";
        String namespace = "com.bbva.tu-equipo";
        String authToken = "tu-bearer-token-aqui";

        boolean success = setupSwiftMessageUpsilon(baseUrl, namespace, authToken);

        if (success) {
            System.out.println("🎉 Upsilon configurado correctamente para procesar mensajes XML/SWIFT desde Kafka");
        } else {
            System.err.println("❌ Error en la configuración de Upsilon");
            System.exit(1);
        }
    }
}
