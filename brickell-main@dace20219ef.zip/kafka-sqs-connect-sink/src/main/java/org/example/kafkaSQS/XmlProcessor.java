package org.example.kafkaSQS;

import org.apache.kafka.connect.sink.SinkRecord;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Clase responsable de procesar mensajes XML y convertirlos a JSON
 * para envío al endpoint de BBVA.
 */
public class XmlProcessor {

    /**
     * Determina si un mensaje es XML basándose en su contenido
     * @param messageBody Contenido del mensaje
     * @return true si es XML, false en caso contrario
     */
    public static boolean isXmlMessage(String messageBody) {
        if (messageBody == null || messageBody.trim().isEmpty()) {
            return false;
        }
        String trimmed = messageBody.trim();
        return trimmed.startsWith("<?xml") ||
               (trimmed.startsWith("<") && trimmed.endsWith(">"));
    }

    /**
     * Extrae datos del mensaje XML usando expresiones regulares
     * @param xmlMessage Mensaje XML completo
     * @return Map con los datos extraídos
     */
    public static Map<String, Object> extractDataFromXml(String xmlMessage) {
        Map<String, Object> data = new HashMap<>();

        try {
            data.put("originalXml", xmlMessage);
            data.put("extractedAt", System.currentTimeMillis());

            // Extraer datos del Header principal
            data.put("direction", extractXmlValue(xmlMessage, "Direction"));
            data.put("protocol", extractXmlValue(xmlMessage, "Protocol"));
            data.put("senderAddress", extractXmlValue(xmlMessage, "SenderAddress"));
            data.put("receiverAddress", extractXmlValue(xmlMessage, "ReceiverAddress"));
            data.put("pdeIndication", extractXmlValue(xmlMessage, "PDEIndication"));

            // Extraer datos de SwiftNet
            data.put("userReference", extractXmlValue(xmlMessage, "UserReference"));
            data.put("requestType", extractXmlValue(xmlMessage, "RequestType"));
            data.put("requestSubType", extractXmlValue(xmlMessage, "RequestSubType"));
            data.put("requestPayloadType", extractXmlValue(xmlMessage, "RequestPayloadType"));

            // Extraer datos del ApplicationHeader CDATA
            String applicationHeader = extractCDataContent(xmlMessage, "ApplicationHeader");
            if (applicationHeader != null) {
                Map<String, String> headerData = extractApplicationHeaderData(applicationHeader);
                data.put("applicationHeader", headerData);
            }

            // Extraer datos del Payload CDATA (PACS)
            String payload = extractCDataContent(xmlMessage, "Payload");
            if (payload != null) {
                Map<String, Object> pacsData = extractPacsData(payload);
                data.put("pacsData", pacsData);
            }

            // Extraer todos los campos adicionales del XML principal
            Map<String, String> customFields = extractAllXmlFields(xmlMessage);
            data.put("customFields", customFields);

        } catch (Exception e) {
            System.err.println("Error extrayendo datos del XML: " + e.getMessage());
            data.put("error", "Error parsing XML: " + e.getMessage());
            data.put("hasError", true);
        }

        return data;
    }

    private static String extractCDataContent(String xml, String elementName) {
        try {
            String pattern = "<" + elementName + "><!\\[CDATA\\[(.*?)\\]\\]></" + elementName + ">";
            Pattern p = Pattern.compile(pattern, Pattern.DOTALL);
            Matcher m = p.matcher(xml);
            if (m.find()) {
                return m.group(1).trim();
            }
        } catch (Exception e) {
            System.err.println("Error extrayendo CDATA para " + elementName + ": " + e.getMessage());
        }
        return null;
    }


    private static Map<String, String> extractApplicationHeaderData(String headerXml) {
        Map<String, String> headerData = new HashMap<>();

        try {
            // Extraer BIC codes
            headerData.put("fromBICFI", extractXmlValueWithNamespace(headerXml, "head:BICFI", true));
            headerData.put("toBICFI", extractXmlValueWithNamespace(headerXml, "head:BICFI", false));

            // Extraer otros campos del header
            headerData.put("bizMsgIdr", extractXmlValueWithNamespace(headerXml, "head:BizMsgIdr", true));
            headerData.put("msgDefIdr", extractXmlValueWithNamespace(headerXml, "head:MsgDefIdr", true));
            headerData.put("bizSvc", extractXmlValueWithNamespace(headerXml, "head:BizSvc", true));
            headerData.put("creDt", extractXmlValueWithNamespace(headerXml, "head:CreDt", true));

        } catch (Exception e) {
            System.err.println("Error extrayendo datos del ApplicationHeader: " + e.getMessage());
        }

        return headerData;
    }

    /**
     * Extrae datos específicos del documento PACS
     */
    private static Map<String, Object> extractPacsData(String pacsXml) {
        Map<String, Object> pacsData = new HashMap<>();

        try {
            // Datos del grupo header
            pacsData.put("msgId", extractXmlValueWithNamespace(pacsXml, "pacs:MsgId", true));
            pacsData.put("creDtTm", extractXmlValueWithNamespace(pacsXml, "pacs:CreDtTm", true));
            pacsData.put("nbOfTxs", extractXmlValueWithNamespace(pacsXml, "pacs:NbOfTxs", true));
            pacsData.put("sttlmMtd", extractXmlValueWithNamespace(pacsXml, "pacs:SttlmMtd", true));

            // Datos de la transacción
            pacsData.put("instrId", extractXmlValueWithNamespace(pacsXml, "pacs:InstrId", true));
            pacsData.put("endToEndId", extractXmlValueWithNamespace(pacsXml, "pacs:EndToEndId", true));
            pacsData.put("uetr", extractXmlValueWithNamespace(pacsXml, "pacs:UETR", true));

            // Información de montos con atributos
            String intrBkSttlmAmt = extractElementWithAttribute(pacsXml, "pacs:IntrBkSttlmAmt", "Ccy");
            String instdAmt = extractElementWithAttribute(pacsXml, "pacs:InstdAmt", "Ccy");
            String chrgsAmt = extractElementWithAttribute(pacsXml, "pacs:Amt", "Ccy");

            pacsData.put("intrBkSttlmAmt", intrBkSttlmAmt);
            pacsData.put("instdAmt", instdAmt);
            pacsData.put("chrgsAmt", chrgsAmt);

            pacsData.put("intrBkSttlmDt", extractXmlValueWithNamespace(pacsXml, "pacs:IntrBkSttlmDt", true));
            pacsData.put("chrgBr", extractXmlValueWithNamespace(pacsXml, "pacs:ChrgBr", true));

            // Datos del deudor
            Map<String, String> debtorData = new HashMap<>();
            debtorData.put("name", extractXmlValueWithNamespace(pacsXml, "pacs:Dbtr>.*?<pacs:Nm", true));
            debtorData.put("account", extractNestedXmlValue(pacsXml, "pacs:DbtrAcct", "pacs:Id"));
            debtorData.put("bicfi", extractNestedXmlValue(pacsXml, "pacs:DbtrAgt", "pacs:BICFI"));
            pacsData.put("debtor", debtorData);

            // Datos del acreedor
            Map<String, String> creditorData = new HashMap<>();
            creditorData.put("name", extractXmlValueWithNamespace(pacsXml, "pacs:Cdtr>.*?<pacs:Nm", true));
            creditorData.put("account", extractNestedXmlValue(pacsXml, "pacs:CdtrAcct", "pacs:Id"));
            creditorData.put("bicfi", extractNestedXmlValue(pacsXml, "pacs:CdtrAgt", "pacs:BICFI"));
            pacsData.put("creditor", creditorData);

        } catch (Exception e) {
            System.err.println("Error extrayendo datos PACS: " + e.getMessage());
        }

        return pacsData;
    }

    /**
     * Extrae valores XML con namespace
     */
    private static String extractXmlValueWithNamespace(String xml, String tagWithNamespace, boolean first) {
        try {
            String pattern = "<" + tagWithNamespace + "(?:\\s[^>]*)?>(.*?)</" + tagWithNamespace.split(":")[0] + ":" + tagWithNamespace.split(":")[1] + ">";
            Pattern p = Pattern.compile(pattern, Pattern.DOTALL);
            Matcher m = p.matcher(xml);

            if (first && m.find()) {
                return m.group(1).trim();
            } else if (!first) {
                // Para el segundo resultado (como el segundo BICFI)
                if (m.find() && m.find()) {
                    return m.group(1).trim();
                }
            }
        } catch (Exception e) {
            System.err.println("Error extrayendo valor con namespace " + tagWithNamespace + ": " + e.getMessage());
        }
        return null;
    }

    /**
     * Extrae elemento con atributo (como montos con moneda)
     */
    private static String extractElementWithAttribute(String xml, String elementName, String attributeName) {
        try {
            String pattern = "<" + elementName + "\\s+" + attributeName + "=\"([^\"]+)\">([^<]+)</" + elementName.split(":")[1] + ">";
            Pattern p = Pattern.compile(pattern);
            Matcher m = p.matcher(xml);
            if (m.find()) {
                return m.group(2) + " " + m.group(1); // "2.00 USD"
            }
        } catch (Exception e) {
            System.err.println("Error extrayendo elemento con atributo: " + e.getMessage());
        }
        return null;
    }

    /**
     * Extrae valores anidados (como cuentas dentro de DbtrAcct)
     */
    private static String extractNestedXmlValue(String xml, String parentTag, String childTag) {
        try {
            String pattern = "<" + parentTag + "(?:\\s[^>]*)?>.*?<" + childTag + "(?:\\s[^>]*)?>([^<]+)</" + childTag.split(":")[1] + ">.*?</" + parentTag.split(":")[1] + ">";
            Pattern p = Pattern.compile(pattern, Pattern.DOTALL);
            Matcher m = p.matcher(xml);
            if (m.find()) {
                return m.group(1).trim();
            }
        } catch (Exception e) {
            System.err.println("Error extrayendo valor anidado: " + e.getMessage());
        }
        return null;
    }

    /**
     * Extrae el valor de un elemento XML específico
     * @param xml Contenido XML
     * @param tagName Nombre del tag a extraer
     * @return Valor del tag o null si no se encuentra
     */
    private static String extractXmlValue(String xml, String tagName) {
        try {
            String pattern = "<" + tagName + "(?:\\s[^>]*)?>\\s*(.*?)\\s*</" + tagName + ">";
            Pattern p = Pattern.compile(pattern, Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
            Matcher m = p.matcher(xml);
            if (m.find()) {
                return m.group(1).trim();
            }
        } catch (Exception e) {
            System.err.println("Error extrayendo valor para tag '" + tagName + "': " + e.getMessage());
        }
        return null;
    }

    /**
     * Extrae todos los elementos XML simples (sin anidamiento)
     * @param xmlMessage Mensaje XML completo
     * @return Map con todos los campos encontrados
     */
    private static Map<String, String> extractAllXmlFields(String xmlMessage) {
        Map<String, String> customFields = new HashMap<>();

        try {
            // Pattern para elementos XML simples: <tag>valor</tag>
            Pattern pattern = Pattern.compile("<([^/>\\s]+)(?:\\s[^>]*)?>\\s*([^<]*)\\s*</\\1>",
                                            Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(xmlMessage);

            while (matcher.find()) {
                String tagName = matcher.group(1).toLowerCase();
                String tagValue = matcher.group(2).trim();

                // Solo agregar si tiene valor y no es un tag común ya procesado
                if (!tagValue.isEmpty() && !isCommonTag(tagName)) {
                    customFields.put(tagName, tagValue);
                }
            }
        } catch (Exception e) {
            System.err.println("Error extrayendo campos personalizados: " + e.getMessage());
        }

        return customFields;
    }

    /**
     * Verifica si un tag es de los campos comunes ya procesados
     */
    private static boolean isCommonTag(String tagName) {
        return tagName.equals("direction") || tagName.equals("protocol") ||
               tagName.equals("senderaddress") || tagName.equals("receiveraddress") ||
               tagName.equals("pdeindication") || tagName.equals("userreference") ||
               tagName.equals("requesttype") || tagName.equals("requestsubtype") ||
               tagName.equals("requestpayloadtype") || tagName.contains("cdata") ||
               tagName.equals("applicationheader") || tagName.equals("payload");
    }

    /**
     * Crea el JSON estructurado para BBVA con los datos del XML
     * @param record Registro de Kafka
     * @param xmlData Datos extraídos del XML
     * @return JSON formateado para BBVA
     */
    public static String createBbvaJsonFromXmlData(SinkRecord record, Map<String, Object> xmlData) {
        StringBuilder json = new StringBuilder();
        json.append("{\n");
        json.append("  \"source\": \"kafka-xml-processor\",\n");
        json.append("  \"kafkaInfo\": {\n");
        json.append("    \"topic\": \"").append(record.topic()).append("\",\n");
        json.append("    \"partition\": ").append(record.kafkaPartition()).append(",\n");
        json.append("    \"offset\": ").append(record.kafkaOffset()).append(",\n");
        json.append("    \"timestamp\": ").append(record.timestamp()).append(",\n");
        json.append("    \"key\": \"").append(record.key() != null ? escapeJsonString(record.key().toString()) : "").append("\"\n");
        json.append("  },\n");
        json.append("  \"messageId\": \"").append(UUID.randomUUID().toString()).append("\",\n");
        json.append("  \"processedAt\": ").append(System.currentTimeMillis()).append(",\n");
        json.append("  \"xmlData\": {\n");

        // Agregar los datos extraídos del XML
        boolean first = true;
        for (Map.Entry<String, Object> entry : xmlData.entrySet()) {
            if (!first) json.append(",\n");
            first = false;

            json.append("    \"").append(entry.getKey()).append("\": ");

            if (entry.getValue() instanceof String) {
                json.append("\"").append(escapeJsonString((String) entry.getValue())).append("\"");
            } else if (entry.getValue() instanceof Map) {
                json.append(mapToJson((Map<String, String>) entry.getValue()));
            } else if (entry.getValue() instanceof Number) {
                json.append(entry.getValue());
            } else if (entry.getValue() instanceof Boolean) {
                json.append(entry.getValue());
            } else {
                json.append("\"").append(escapeJsonString(String.valueOf(entry.getValue()))).append("\"");
            }
        }

        json.append("\n  }\n");
        json.append("}");

        return json.toString();
    }

    /**
     * Convierte un Map a JSON
     */
    private static String mapToJson(Map<String, String> map) {
        StringBuilder json = new StringBuilder("{\n");
        boolean first = true;
        for (Map.Entry<String, String> entry : map.entrySet()) {
            if (!first) json.append(",\n");
            first = false;
            json.append("      \"").append(entry.getKey()).append("\": \"")
                .append(escapeJsonString(entry.getValue())).append("\"");
        }
        json.append("\n    }");
        return json.toString();
    }

    /**
     * Escapa caracteres especiales para JSON
     */
    private static String escapeJsonString(String str) {
        if (str == null) return "";
        return str.replace("\\", "\\\\")
                  .replace("\"", "\\\"")
                  .replace("\n", "\\n")
                  .replace("\r", "\\r")
                  .replace("\t", "\\t")
                  .replace("\b", "\\b")
                  .replace("\f", "\\f");
    }
}
