# Kafka-Upsilon Connector

Este proyecto es un **conector de Kafka para Upsilon Streams** que permite el envío de mensajes desde un tópico de Kafka hacia streams de Upsilon. Utiliza Upsilon Streams para almacenamiento governado de datos con esquemas definidos.

## Características

- **Kafka a Upsilon (Sink Connector)**: Consume mensajes de un tópico de Kafka y los envía a Upsilon Streams.
- **Procesamiento XML → JSON**: Transforma mensajes XML a JSON estructurado antes del envío.
- **Esquemas governados**: Usa Record Types de Upsilon para validación de datos.
- **Persistencia e historial**: Capacidad de almacenar y recuperar historial de mensajes.
- **Dual routing**: Mensajes XML van a Upsilon, otros mensajes van a SQS.

## Arquitectura del Flujo

```
Kafka Topic (XML) → XmlProcessor → JSON → Upsilon Stream → Múltiples Consumidores
Kafka Topic (otros) → SQS FIFO
```

## Requisitos

- **Java 17 o superior**
- **Apache Kafka** con Kafka Connect habilitado
- **Credenciales ECS Platform** con acceso a Upsilon
- **Bearer Token de Portunus** para autenticación

## Configuración

### Configuración Completa del Conector

```properties
# Configuración básica
name=upsilon-sink-connector
connector.class=org.example.kafkaSQS.SqsSinkConnector
tasks.max=1
topics=xml-messages,swift-messages

# Configuración SQS (para mensajes no-XML)
sqs.queue.url=https://sqs.eu-west-1.amazonaws.com/123456789012/mi-cola-fifo.fifo
aws.access.key=tu-aws-access-key
aws.secret.key=tu-aws-secret-key
aws.region=eu-west-1

# Configuración Upsilon Streams
upsilon.base.url=https://upsilon.work-01.platform.bbva.com/v1
upsilon.namespace=com.bbva.tunamespace
upsilon.stream.id=kafka-xml-messages
upsilon.record.type.id=SwiftMessageRecord
upsilon.auth.token=tu-bearer-token-de-portunus
upsilon.topics=xml-messages,swift-messages
upsilon.enabled=true
upsilon.store=standard

# Configuración de proxy (opcional)
proxy.host=proxy.bbva.com
proxy.port=8080
```

### Tipos de Stores Upsilon

| Store | Propósito | Rendimiento | Uso Recomendado |
|-------|-----------|-------------|-----------------|
| **standard** | Eventos comerciales y bancarios | ~10k registros/s | Transacciones SWIFT, pagos |
| **monitoring** | Intervalos y logs | ~10k registros/s | Métricas, auditoría |
| **standardaws** | Standard en AWS | ~10k registros/s | Cargas en AWS |
| **monitoringaws** | Monitoring en AWS | ~10k registros/s | Logs en AWS |

## Configuración de Esquemas

### 1. Record Type JSON
```json
{
  "_id": "SwiftMessageRecord",
  "description": "Esquema para mensajes XML procesados",
  "protoSpec": {
    "messageType": "string",
    "originalFormat": "string", 
    "direction": "string",
    "senderAddress": "string",
    "receiverAddress": "string",
    "amount": "string",
    "currency": "string",
    "sourceTopic": "string",
    "processedAt": "int64",
    "messageFormat": "string",
    "connectorOrigin": "string",
    "streamTimestamp": "int64",
    "originalXml": "string"
  }
}
```

### 2. Record Type Protobuf
```protobuf
syntax = "proto3";

package semaas;

message SwiftMessageRecord {
    string messageType = 1;
    string originalFormat = 2;
    string direction = 3;
    string senderAddress = 4;
    string receiverAddress = 5;
    string amount = 6;
    string currency = 7;
    string sourceTopic = 8;
    int64 processedAt = 9;
    string messageFormat = 10;
    string connectorOrigin = 11;
    int64 streamTimestamp = 12;
    string originalXml = 13;
    KafkaMetadata kafkaMetadata = 14;
}

message KafkaMetadata {
    string topic = 1;
    int32 partition = 2;
    int64 offset = 3;
    int64 timestamp = 4;
    string timestampType = 5;
    string key = 6;
}
```

## Despliegue

### 1. Compilar el proyecto
```bash
mvn clean package
```

### 2. Copiar JAR a Kafka Connect
```bash
cp target/kafka-sqs-connect-1.0-SNAPSHOT-shaded.jar $KAFKA_HOME/libs/
```

### 3. Crear infraestructura Upsilon
Usar la colección de Postman incluida o comandos curl:

```bash
# 1. Crear Record Type
curl -k -H "Authorization: Bearer <TOKEN>" \
  https://upsilon.work-01.platform.bbva.com/v1/ns/namespace/record-types \
  -d '{"_id": "SwiftMessageRecord", "protoSpec": {...}}'

# 2. Crear Stream  
curl -k -H "Authorization: Bearer <TOKEN>" \
  https://upsilon.work-01.platform.bbva.com/v1/ns/namespace/streams \
  -d '{"_id": "kafka-xml-messages", "recordType": "//upsilon.work-01/ns/namespace/record-types/SwiftMessageRecord"}'
```

### 4. Desplegar conector
```bash
# Configurar conector
curl -X POST http://localhost:8083/connectors \
  -H "Content-Type: application/json" \
  -d @config/upsilon-sink-connector.properties

# Verificar estado
curl http://localhost:8083/connectors/upsilon-sink-connector/status
```

## Ventajas de Upsilon vs PSI

### ✅ **Governance y Esquemas**
- Validación automática de datos contra record types
- Evolución controlada de esquemas (solo adición de campos)
- Trazabilidad completa de cambios

### ✅ **Persistencia e Historial**
- Almacenamiento a largo plazo de mensajes
- Capacidad de replay desde cualquier offset
- Acceso al historial completo de eventos

### ✅ **Rendimiento Empresarial**
- ~10,000 registros/segundo
- Latencia ~45ms
- Hasta 100 millones de registros persistentes

### ✅ **Integración BBVA**
- Nativo del ecosistema BBVA
- Permisos granulares y roles
- Compartición segura entre múltiples equipos

## Flujo de Datos Completo

```
1. Kafka Topic: xml-messages
   ↓
2. SqsSinkTask: Detecta XML
   ↓  
3. XmlProcessor: XML → JSON estructurado
   ↓
4. UpsilonClient: Validación contra esquema
   ↓
5. Upsilon Stream: Almacenamiento governado
   ↓
6. Múltiples Consumidores: Tiempo real + batch
```

## Monitoreo y Debugging

```bash
# Ver logs del conector
tail -f $KAFKA_HOME/logs/connect.log

# Estado del conector  
curl localhost:8083/connectors/upsilon-sink-connector/status

# Registros en Upsilon
curl -H "Authorization: Bearer <TOKEN>" \
  https://upsilon.work-01.platform.bbva.com/v1/ns/namespace/streams/kafka-xml-messages:getRecords \
  -d '{"from": 0, "limit": 10}'
```

## Testing con Postman

Incluye colección completa: `PSI-Kafka-Connector.postman_collection.json`

1. **Importar** colección en Postman
2. **Configurar variables** de entorno
3. **Ejecutar** requests en orden:
   - Crear Record Type
   - Crear Stream  
   - Desplegar Conector
   - Probar envío de mensajes

## Estructura de Mensaje Procesado

Los mensajes XML se transforman a este formato JSON:

```json
{
  "messageType": "swift-mt103",
  "originalFormat": "xml", 
  "direction": "outgoing",
  "senderAddress": "BBVAESMMXXX",
  "receiverAddress": "DEUTDEFFXXX",
  "amount": "10000.00",
  "currency": "EUR",
  "sourceTopic": "xml-messages",
  "processedAt": 1634567890123,
  "messageFormat": "xml",
  "connectorOrigin": "kafka-upsilon-connector", 
  "streamTimestamp": 1634567890123,
  "originalXml": "<?xml version=\"1.0\"?>...",
  "kafkaMetadata": {
    "topic": "xml-messages",
    "partition": 0,
    "offset": 12345,
    "timestamp": 1634567890123
  }
}
```

Este formato está optimizado para Upsilon Streams y mantiene toda la trazabilidad del mensaje original desde Kafka.
